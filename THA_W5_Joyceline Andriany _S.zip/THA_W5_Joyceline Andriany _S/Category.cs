﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlinkShop
{
    internal class Category
    {
        private string _id, _nama;

        public Category(string id, string nama)
        {
            _id = id;
            _nama = nama;
        }

        public object[] asDataRow()
        {
            object[] data = { this, _id, _nama};
            return data;
        }

        public string Id { get { return _id; } }
        public string Nama { get { return _nama; } }
        
    }
}
