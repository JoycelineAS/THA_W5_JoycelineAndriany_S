﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlinkShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnAddCategory.BackColor = Color.Green;
            btnAddProduct.BackColor = Color.Green;
            btnEditProduct.BackColor = Color.Yellow;
            btnRemoveCategory.BackColor = Color.Red;
            btnRemoveProduct.BackColor = Color.Red;
            this.defaultFill();
        }
        DataTable dtProduct = new DataTable();
        DataTable dtProductFilter = new DataTable();
        DataTable dtCategory = new DataTable();
        List<Product> productList = new List<Product>();
        List<Category> categoryList = new List<Category>();
        List<LabelCounter> labelCounterList = new List<LabelCounter>();
        int categoryCtr = 1;

        private void refreshProductList()
        {
            dtProduct.Rows.Clear();
            foreach (Product product in productList)
            {
                dtProduct.Rows.Add(product.asDataRow());
            }

        }
        private void refreshCategoryList()
        {
            dtCategory.Rows.Clear();
            foreach (Product product in productList)
            {
                dtCategory.Rows.Add(product.asDataRow());
            }

        }
        private string getID(string label, string prefix, int leftPad = 0) {
            foreach (LabelCounter labelCounter in labelCounterList)
            {
                if (labelCounter.tryGet(label) != null)
                {
                    return prefix + labelCounter.assignCounter(leftPad);
                }
            }
            LabelCounter newLabelCounter = new LabelCounter(label);
            labelCounterList.Add(newLabelCounter);
            return prefix + newLabelCounter.assignCounter(leftPad);
        }
        private void defaultFill()
        {
            dtCategory.Columns.Add("object", typeof(Category));
            dtCategory.Columns.Add("ID Category", typeof(string));
            dtCategory.Columns.Add("Nama Category", typeof(string));
            
            Category c1 = new Category(getID("CATEGORY", "C"), "Jas");
            Category c2 = new Category(getID("CATEGORY", "C"), "T-Shirt");
            Category c3 = new Category(getID("CATEGORY", "C"), "Rok");
            Category c4 = new Category(getID("CATEGORY", "C"), "Celana");
            Category c5 = new Category(getID("CATEGORY", "C"), "Cawat");

            dtCategory.Rows.Add(c1.asDataRow());
            dtCategory.Rows.Add(c2.asDataRow());
            dtCategory.Rows.Add(c3.asDataRow());
            dtCategory.Rows.Add(c4.asDataRow());
            dtCategory.Rows.Add(c5.asDataRow());

            dgCategory.DataSource = dtCategory;
            dgCategory.Columns[0].Visible = false;

            dtProduct.Columns.Add("object", typeof(Product));
            dtProduct.Columns.Add("ID Product", typeof(string));
            dtProduct.Columns.Add("Nama Product", typeof(string));
            dtProduct.Columns.Add("Harga", typeof(int));
            dtProduct.Columns.Add("Stock", typeof(int));
            dtProduct.Columns.Add("ID Category", typeof(string));


            dtProduct.Rows.Add(new Product(getID("PRODUCT-J", "J", 3), "Jas Hitam", c1, 10000, 10).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-T", "T", 3), "T-Shirt Black Pink", c2, 70000, 20).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-T", "T", 3), "T-Shirt Obsessive", c4, 75000, 16).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-R", "R", 3), "Rok Mini", c3, 82000, 26).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-J", "J", 3), "Jeans Biru", c4, 90000, 5).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-C", "C", 3), "Celana Pendek Coklat", c4, 60000, 11).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-C", "C", 3), "Cawat Blink-Blink", c5, 1000000, 1).asDataRow());
            dtProduct.Rows.Add(new Product(getID("PRODUCT-R", "R", 3), "Rocca Shirt", c2, 50000, 8).asDataRow());

            dgProduct.DataSource = dtProduct;
            dgProduct.Columns[0].Visible = false;
            refreshCbCategory();
        }
        private void refreshCbCategory()
        {
            cbFilterCategory.Items.Clear();
            cbInputPrCategory.Items.Clear();
            foreach (DataRow item in dtCategory.Rows)
            {
                Category cat = item.ItemArray[0] as Category;
                cbFilterCategory.Items.Add(cat.Nama);
                cbInputPrCategory.Items.Add(cat.Nama);
            }
        }

        private void dgProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgProduct.SelectedRows.Count == 0)
            {
                tbProductName.Text = "";
                tbProductPrice.Text = "";
                tbProductStock.Text = "";
                cbInputPrCategory.SelectedIndex = -1;
                return;
            }
            Product selectedProduct = dgProduct.SelectedRows[0].Cells[0].Value as Product;
            tbProductName.Text = selectedProduct.Nama;
            tbProductPrice.Text = selectedProduct.Harga.ToString();
            tbProductStock.Text = selectedProduct.Stock.ToString();
            cbInputPrCategory.SelectedItem = selectedProduct.Category.Nama;
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            string categoryName = tbCategoryName.Text;
            if (categoryName.Equals(""))
            {
                MessageBox.Show("Nama Category belum diisi");
                return;
            }
            if(getCategoryByName(categoryName)!=null)
            {
                MessageBox.Show("Category sudah ada");
                return;
            }
            dtCategory.Rows.Add(new Category(getID("CATEGORY", "C"), categoryName).asDataRow());
            refreshCbCategory();
        }

        private void btnAllProduct_Click(object sender, EventArgs e)
        {
            cbFilterCategory.Enabled = false ;
            cbFilterCategory.SelectedIndex = -1;
            dgProduct.DataSource = dtProduct;
        }

        private void btnFilterProduct_Click(object sender, EventArgs e)
        {
            cbFilterCategory.Enabled = true;
        }

        private void cbFilterCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterCategory.SelectedIndex < 0)
            {
                return;
            }
            Category selectedCategory = getCategoryByName(cbFilterCategory.SelectedItem as string);
            filterProductDGV(selectedCategory);
            dgProduct.DataSource = dtProductFilter;
            return;
        }
        

        private void filterProductDGV(Category category)
        {
            dtProductFilter = dtProduct.Clone();
            for (int i = dtProduct.Rows.Count - 1; i >= 0; i--)
            {
                DataRow row = dtProduct.Rows[i];
                Product rowProduct = row.ItemArray[0] as Product;
                if (rowProduct.Category.Equals(category))
                {
                    dtProductFilter.Rows.Add(rowProduct.asDataRow());
                }

            }

        }

        private Category getCategoryByName(string category) {

            foreach (DataRow item in dtCategory.Rows)
            {
                Category cat = item.ItemArray[0] as Category;
                if (cat.Nama.Equals(category)) return cat;
            }
            return null;
        }

        private void btnRemoveCategory_Click(object sender, EventArgs e)
        {
            List<DataGridViewRow> forDelete = new List<DataGridViewRow>();
            List<Category> forDeleteCategory = new List<Category>();
            foreach (DataGridViewRow item in dgCategory.SelectedRows)
            {
                forDelete.Add(item);
                forDeleteCategory.Add(item.Cells[0].Value as Category);
            }
            foreach (DataGridViewRow row in forDelete)
            {
                dgCategory.Rows.Remove(row);
            }
            foreach (Category categoryToDelete in forDeleteCategory)
            {
                for (int i = dtProduct.Rows.Count - 1; i >= 0; i--)
                {
                    DataRow row = dtProduct.Rows[i];
                    Product rowProduct = row.ItemArray[0] as Product;
                    if (rowProduct.Category.Equals(categoryToDelete))
                    {
                        dtProduct.Rows.Remove(row);
                    }

                }
            }
            cbFilterCategory_SelectedIndexChanged(sender, e);
            refreshCbCategory();
        }
        string lastProductPriceText = "";
        private void tbProductPrice_TextChanged(object sender, EventArgs e)
        {
        }

        private void tbProductPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            
            List<string> empty = new List<string>();
            if (tbProductName.Text.Equals(""))
                empty.Add("nama");
            if (cbInputPrCategory.SelectedIndex < 0)
                empty.Add("category");
            if (tbProductPrice.Text.Equals(""))
                empty.Add("harga");
            if (tbProductStock.Text.Equals(""))
                empty.Add("stock");
            if (empty.Count > 0)
            {
                MessageBox.Show("Inputan berikut masih kosong \n" + string.Join("\n", empty));
                return;
            }
            Category getCategory = getCategoryByName(cbInputPrCategory.SelectedItem as string);
            if (getCategory == null)
            {
                MessageBox.Show("Category tidak valid"); ;
            }
            dtProduct.Rows.Add(
                new Product(
                    getID("PRODUCT-" + tbProductName.Text[0], tbProductName.Text[0] + "", 3),
                    tbProductName.Text,
                    getCategory,
                    int.Parse(tbProductPrice.Text),
                    int.Parse(tbProductStock.Text)
                ).asDataRow()
            );
            cbFilterCategory_SelectedIndexChanged(sender, e);
        }

        private void dgProduct_SelectionChanged(object sender, EventArgs e)
        {
            dgProduct_CellContentClick(sender, null);
        }

        private void btnRemoveProduct_Click(object sender, EventArgs e)
        {
            if (dgProduct.SelectedRows.Count < 1)
            {
                MessageBox.Show("Pilih product terlebih dahulu");
                return;
            }
            List<Product> forDeleteProduct = new List<Product>();
            foreach (DataGridViewRow item in dgProduct.SelectedRows)
            {
                forDeleteProduct.Add(item.Cells[0].Value as Product);
            }
            List<DataRow> forDeleteRow = new List<DataRow>();
            foreach (Product row in forDeleteProduct)
            {
                foreach (DataRow item in dtProduct.Rows)
                {
                    if ((item.ItemArray[0] as Product).Equals(row))
                    {
                        forDeleteRow.Add(item);
                    }
                }
            }
            foreach (DataRow deleteRow in forDeleteRow)
            {
                dtProduct.Rows.Remove(deleteRow);
            }
            cbFilterCategory_SelectedIndexChanged(sender, e);
        }

        private void dgCategory_SelectionChanged(object sender, EventArgs e)
        {
            if (dgCategory.SelectedRows.Count == 0)
            {
                return;
            }
            Category selectedCategory = dgCategory.SelectedRows[0].Cells[0].Value as Category;
            tbCategoryName.Text = selectedCategory.Nama;
        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {
            if (dgProduct.SelectedRows.Count == 0)
            {
                MessageBox.Show("Belum Memilih Item");
                return;
            }
            List<string> empty = new List<string>();
            if (tbProductName.Text.Equals(""))
                empty.Add("nama");
            if (cbInputPrCategory.SelectedIndex < 0)
                empty.Add("category");
            if (tbProductPrice.Text.Equals(""))
                empty.Add("harga");
            if (tbProductStock.Text.Equals(""))
                empty.Add("stock");
            if (empty.Count > 0)
            {
                MessageBox.Show("Inputan berikut masih kosong \n" + string.Join("\n", empty));
                return;
            }
            Category getCategory = getCategoryByName(cbInputPrCategory.SelectedItem as string);
            if (getCategory == null)
            {
                MessageBox.Show("Category tidak valid"); ;
            }
            
            Product selectedProduct = dgProduct.SelectedRows[0].Cells[0].Value as Product;
            selectedProduct.setName(tbProductName.Text);
            selectedProduct.setCategory(getCategory);
            selectedProduct.setHarga(int.Parse(tbProductPrice.Text));
            selectedProduct.setStock(int.Parse(tbProductStock.Text));
            foreach (DataRow row in dtProduct.Rows)
            {
                if ((row.ItemArray[0] as Product).Equals(selectedProduct))
                {
                    if (selectedProduct.Stock <= 0)
                    {
                        dtProduct.Rows.Remove(row);
                        return;
                    }
                    row.ItemArray = selectedProduct.asDataRow();
                    cbFilterCategory_SelectedIndexChanged(sender, e);
                    return;
                }
            }
            
        }

        private void dgProduct_DataSourceChanged(object sender, EventArgs e)
        {

        }

        private void dgCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
