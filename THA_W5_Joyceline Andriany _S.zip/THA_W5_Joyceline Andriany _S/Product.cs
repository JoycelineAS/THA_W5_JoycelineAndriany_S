﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlinkShop
{
    internal class Product
    {
        private string _id,_nama;
        private Category _category;
        private int _harga, _stock;

        public Product(string id,string nama, Category category, int harga, int stock)
        {
            _id = id;
            _nama = nama;
            _category = category;
            _harga = harga;
            _stock = stock;
        }
        public string Id { get { return _id; } }
        public string Nama { get { return _nama; } }
        public int Harga { get { return _harga; } }
        public int Stock { get { return _stock; } }
        

        public object[] asDataRow() {
            object[] data = { this, _id, _nama, _harga, _stock, _category.Id };
            return data;
        }
        public Category Category { get { return _category; } }

        public void setName(string nama)
        {
            _nama = nama;
        }
        public void setCategory(Category category)
        {
            _category = category;
        }
        public void setStock(int stock)
        {
            _stock = stock;
        }
        public void setHarga(int harga)
        {
            _harga = harga;
        }

        
    }
}
