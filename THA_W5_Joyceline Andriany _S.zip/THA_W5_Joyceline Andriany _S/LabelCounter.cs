﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlinkShop
{
    internal class LabelCounter
    {
        private string _label;
        private int _counter;

        public LabelCounter(string label)
        {
            _label = label;
            _counter = 0;
        }
        public string assignCounter(int leftPad = 0)
        {
            _counter++;
            return _counter.ToString().PadLeft(leftPad, '0');
        }
        public LabelCounter tryGet(string label) {
            return (label.Equals(_label)) ? this : null;
        }
        
    }
}
